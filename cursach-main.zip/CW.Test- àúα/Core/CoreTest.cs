﻿using System.Windows.Controls;

namespace CW.Test.Core
{
    public static class CoreTest
    {
        public static Frame? TestFrame { get; set; }
    }
}