﻿using CW.Test.Core;
using System;
using System.Globalization;
using System.Printing;
using System.Windows;
using System.Windows.Controls;

namespace CW.Test.View.Pages.PageTask
{
    /// <summary>
    /// Логика взаимодействия для TaskPage.xaml
    /// </summary>
    public partial class Task1Page : Page
    {
        public Task1Page()
        {
            InitializeComponent();
        }
        private void BtnTask1_Click(object sender, RoutedEventArgs e)
        {
            CoreTest.TestFrame?.Navigate(new Task1Page());
        }
        private void BtnTask2_Click(object sender, RoutedEventArgs e)
        {
            CoreTest.TestFrame?.Navigate(new Task2Page());
        }
        private void BtnTask3_Click(object sender, RoutedEventArgs e)
        {
            CoreTest.TestFrame?.Navigate(new Task3Page());
        }
        private void BtnTask4_Click(object sender, RoutedEventArgs e)
        {
            CoreTest.TestFrame?.Navigate(new Task4Page());
        }
        private void BtnTask5_Click(object sender, RoutedEventArgs e)
        {
            CoreTest.TestFrame?.Navigate(new Task5Page());
        }
        private void BtnLogout_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Вы действительно хотите выйти?",
                "Системное сообщение",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                CoreTest.TestFrame?.Navigate(new MainPage());
            }
        }

        private void Q1B(object sender, RoutedEventArgs e)
        {
            static int NOD(int A, int B)
            {
                if (A == 0)
                    return B;
                else
                {
                    int R = B % A;
                    return NOD(R, A);
                }
            }

            int A = 10;
            int B = 15;
            int C = 20;
            int D = 25;

            int NOD_AB = NOD(A, B);
            int NOD_AC = NOD(A, C);
            int NOD_AD = NOD(A, D);

            Q1I.Text = "NOD(" + A + ", " + B + ") = " + NOD_AB + "\n";
            Q1I.Text += "NOD(" + A + ", " + C + ") = " + NOD_AC + "\n";
            Q1I.Text += "NOD(" + A + ", " + D + ") = " + NOD_AD;
        }
    }
}