﻿using CW.Test.Core;
using System.Windows;
using System.Windows.Controls;

namespace CW.Test.View.Pages.PageTask
{
    /// <summary>
    /// Логика взаимодействия для TaskPage.xaml
    /// </summary>
    public partial class Task4Page : Page
    {
        public Task4Page()
        {
            InitializeComponent();
        }
        private void BtnTask1_Click(object sender, RoutedEventArgs e)
        {
            CoreTest.TestFrame?.Navigate(new Task1Page());
        }
        private void BtnTask2_Click(object sender, RoutedEventArgs e)
        {
            CoreTest.TestFrame?.Navigate(new Task2Page());
        }
        private void BtnTask3_Click(object sender, RoutedEventArgs e)
        {
            CoreTest.TestFrame?.Navigate(new Task3Page());
        }
        private void BtnTask4_Click(object sender, RoutedEventArgs e)
        {
            CoreTest.TestFrame?.Navigate(new Task4Page());
        }
        private void BtnTask5_Click(object sender, RoutedEventArgs e)
        {
            CoreTest.TestFrame?.Navigate(new Task5Page());
        }
        private void BtnLogout_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Вы действительно хотите выйти?",
                "Системное сообщение",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                CoreTest.TestFrame?.Navigate(new MainPage());
            }
        }

        public static bool Simm(string S)
        {
            if (S.Length <= 1)
            {
                return true;
            }
            else if (S[0] != S[S.Length - 1])
            {
                return false;
            }
            else
            {
                string remaining = S.Substring(1, S.Length - 2);
                return Simm(remaining);
            }
        }

        private void Q4B(object sender, RoutedEventArgs e)
        {
            // Задать значения в строке
            // Работает только с англ.яз
            string[] strings = { "racecar", "level", "sos", "world", "hell" };
            string results = "";

            foreach (string s in strings)
            {
                bool isSymmetric = Simm(s);
                results += $"{s}: {(isSymmetric ? "Симметрична" : "Не симметрична")}\n";
            }

            Q4I.Text = results;
        }

    }
}