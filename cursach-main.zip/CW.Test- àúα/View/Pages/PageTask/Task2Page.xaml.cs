﻿using CW.Test.Core;
using System.Windows;
using System.Windows.Controls;

namespace CW.Test.View.Pages.PageTask
{
    /// <summary>
    /// Логика взаимодействия для TaskPage.xaml
    /// </summary>
    public partial class Task2Page : Page
    {
        public Task2Page()
        {
            InitializeComponent();
        }
        private void BtnTask1_Click(object sender, RoutedEventArgs e)
        {
            CoreTest.TestFrame?.Navigate(new Task1Page());
        }
        private void BtnTask2_Click(object sender, RoutedEventArgs e)
        {
            CoreTest.TestFrame?.Navigate(new Task2Page());
        }
        private void BtnTask3_Click(object sender, RoutedEventArgs e)
        {
            CoreTest.TestFrame?.Navigate(new Task3Page());
        }
        private void BtnTask4_Click(object sender, RoutedEventArgs e)
        {
            CoreTest.TestFrame?.Navigate(new Task4Page());
        }
        private void BtnTask5_Click(object sender, RoutedEventArgs e)
        {
            CoreTest.TestFrame?.Navigate(new Task5Page());
        }
        private void BtnLogout_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Вы действительно хотите выйти?",
                "Системное сообщение",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                CoreTest.TestFrame?.Navigate(new MainPage());
            }
        }
        public double MinRec(double[] A, int N)
        {
            if (N == 1)
            {
                return A[0];
            }
            else
            {
                double min = MinRec(A, N - 1);
                return A[N - 1] < min ? A[N - 1] : min;
            }
        }

        private void Q2B(object sender, RoutedEventArgs e)
        {
            // Задать элемент массива
            double[] A = { 1.0, 2.0, 3.0 };
            double[] B = { -1.0, 0.0, 1.0 };
            double[] C = { 0.5, 1.5, 2.5 };

            int NA = A.Length;
            int NB = B.Length;
            int NC = C.Length;

            double minA = MinRec(A, NA);
            double minB = MinRec(B, NB);
            double minC = MinRec(C, NC);

            Q2I.Text += $" {minA}, {minB}, {minC}";
        }
    }
}